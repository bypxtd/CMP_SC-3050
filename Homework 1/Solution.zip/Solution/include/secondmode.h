#ifndef H_SECONDMODE_H
#define H_SECONDMODE_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>


void sort_vector(struct vector* v, unsigned int left, unsigned int right);
unsigned int second_mode(struct vector *v);
#endif
