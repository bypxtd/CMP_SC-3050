#ifndef H_PARSING_H
#define H_PARSING_H
#include <inttypes.h>
#include <ctype.h>
#include "graph.h"

void parse_getline(FILE* fp, struct graph *grph);

#endif
